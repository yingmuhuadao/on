package msg

import (
	"github.com/name5566/leaf/network/protobuf"
)

var Processor = protobuf.NewProcessor()

func init() {
	Processor.Register(&Request{})
	Processor.Register(&Response{})
	Processor.Register(&Push{})
	Processor.Register(&Ack{})
}
