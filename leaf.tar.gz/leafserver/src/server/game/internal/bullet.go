package internal

import (
	"time"
	"math"
)

type TargetType int
const (
	_ TargetType = iota
	TargetTypeBullet
	TargetTypeProp
	TargetTypeMember
)

type Bullet struct {
	bulletId string
	x float64
	y float64
	vx float64
	vy float64
	player *Member
}

func NewBullet(player *Member, bulletId string, y float64) *Bullet {
	return &Bullet{
		bulletId: bulletId,
		x: BulletX,
		y: y,
		vx: BulletSpeed,
		vy: 0,
		player: player,
	}
}

func (bullet *Bullet) update(duration int64) {
	dt := float64(duration) / float64(time.Second)
	bullet.x += bullet.vx * dt
	if bullet.x > MaxX {
		bullet.player.removeBullet(bullet)
	}
}

func (bullet *Bullet) collide(targetType TargetType, target interface{}) bool {
	switch targetType {
	case TargetTypeBullet:
		// 子弹的坐标都是从左到右，所以对面的需要加个-
		return bullet.distance(-target.(*Bullet).x, target.(*Bullet).y) - BulletRaidus < BulletRaidus
	case TargetTypeProp:
		return bullet.distance(0, target.(*Prop).position) - BulletRaidus < PropRadius
	case TargetTypeMember:
		return bullet.distance(PlayerX, target.(*Member).position) - BulletRaidus < PlayerRadius
	}
	return false
}

func (bullet *Bullet) distance(x float64, y float64) float64 {
	return math.Sqrt(math.Pow(bullet.x - x, 2) + math.Pow(bullet.y - y, 2))
}
