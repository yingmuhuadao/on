package internal

import (
	"math/rand"
	"time"
	"strconv"
)

type PropType int
const (
	_ PropType = iota
	PropTypeShield
	PropTypeTrack
)

type Prop struct {
	propId string
	position float64
	propType PropType
	showTime int64
	area int64
	room *RoomInfo
	shown bool
}

func NewProp(room *RoomInfo, propType PropType, otherArea int64) *Prop {
	prop := &Prop{
		propId: "",
		position: 0,
		propType: propType,
		showTime: 0,
		area: 0,
		room: room,
		shown: false,
	}
	prop.init(otherArea)
	return prop
}

func getRand(num int64) int64 {
	source := rand.NewSource(time.Now().UnixNano())
	random := rand.New(source)
	return random.Int63n(num)
}

func (prop *Prop) init(otherArea int64) {
	areaSize := int64((MaxY - MinY - PropAreaMargin * 2) / PropAreaCount)
	position := float64(getRand(areaSize - PropRadius * 2))
	area := getRand(PropAreaCount)
	if area == otherArea {
		area = (area + 1) % PropAreaCount
	}
	showTime := getRand(MaxShowPropTimeInterval)
	position += MinY + PropAreaMargin + float64(area * areaSize)
	prop.position = position
	prop.propId = strconv.FormatInt(time.Now().UnixNano(), 10)
	prop.showTime = showTime
	prop.area = area
}

func (prop *Prop) update(duration int64) {
	if !prop.shown {
		prop.showTime -= duration
		if prop.showTime <= 0 {
			prop.shown = true
			prop.room.showProp(prop.propType)
		}
	}
}

func (prop *Prop) isShield() bool {
	return prop.propType == PropTypeShield
}

func (prop *Prop) isTrack() bool {
	return prop.propType == PropTypeTrack
}
