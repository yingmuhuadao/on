package internal

import "time"

const ReadyTimeInterval = int64(1 * time.Second)  // ready的动画时间
const RoundTimeInterval = int64(30800 * time.Millisecond)
const ShootTimeInterval = int64(2 * time.Second)
const SyncTimeInterval = int64(90 * time.Millisecond)
const MaxShowPropTimeInterval  = int64(15 * time.Second)
const RestTimeInterval = int64(3 * time.Second)

// 战斗区域坐标为 (-320, -460) 到 (320, 300)
const MaxY = 300
const MinY = -460
const MaxX = 320

const InitPlayerSpeed = 525
const PlayerGravity = -1000
const PlayerX = 250
const PlayerRadius = 80

const BulletY = -35
const BulletX = -180
const BulletSpeed = 650
const BulletRaidus = 20

const PropRadius = 30
const PropAreaCount = 4
const PropAreaMargin = 80
