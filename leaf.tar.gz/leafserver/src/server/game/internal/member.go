package internal

import (
	"time"
	"fmt"
)

type Member struct {
	userId string
	life int32
	position float64
	speed float64
	alive bool
	bullets []*Bullet
	hasShield bool
	hasTrack bool
}

func NewMember(userId string) *Member {
	member := &Member{
		userId: userId,
		life: 3,
		position: MinY,
		speed: 0,
		alive: true,
		bullets: []*Bullet{},
		hasShield: false,
		hasTrack: false,
	}
	member.init()
	return member
}

func (member *Member) init() {
	member.position = MinY
	member.speed = 0
	member.alive = true
	member.bullets = []*Bullet{}
	member.hasShield = false
	member.hasTrack = false
}

func (member *Member) update(duration int64)  {
	dt := float64(duration) / float64(time.Second)
	if member.position > MinY || member.speed > 0 {
		member.position += member.speed * dt + 0.5 * PlayerGravity * dt * dt
		member.speed += dt * PlayerGravity
		if member.position >= MaxY {
			member.speed = 0
			member.position = MaxY
		}
		if member.position <= MinY {
			member.position = MinY
			member.speed = 0
		}
	}
	for _, bullet := range member.bullets {
		bullet.update(duration)
	}
}

func (member *Member) fly() {
	member.speed = InitPlayerSpeed
}

func (member *Member) shoot(count int) {
	now := time.Now().UnixNano()
	for i:=0; i<count; i++ {
		bullet := NewBullet(member, member.getBulletId(now + int64(i)), member.position + BulletY + member.getOffset(i, count))
		member.bullets = append(member.bullets, bullet)
	}
}

func (member *Member) getBulletId(index int64) string {
	return fmt.Sprintf("%s_%d", member.userId, index)
}

func (member *Member) getOffset(index int, count int) float64 {
	if count == 1 {
		return 0
	} else if count == 2 {
		return float64(1 - 2 * index) * 20
	} else if count == 3 {
		return float64(1 - index) * 40
	}
	return 0
}

func (member *Member) removeBullet(bullet *Bullet) {
	for index, value := range member.bullets {
		if value == bullet {
			member.bullets = append(member.bullets[:index], member.bullets[index+1:]...)
		}
	}
}

func (member *Member) gotProp(prop *Prop) {
	if prop.isShield() {
		member.hasShield = true
	} else if prop.isTrack() {
		member.hasTrack = true
	}
}

func (member *Member) loseShield() {
	member.hasShield = false
}
