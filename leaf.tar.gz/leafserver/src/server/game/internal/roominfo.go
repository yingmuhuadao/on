package internal

import (
	"time"
	"github.com/name5566/leaf/log"
)

type RoomState int
const (
	_ RoomState = iota
	RoomStateCreating
	RoomStateWaiting
	RoomStatePlaying
	RoomStateResting
	RoomStateOver
)

type RoomNotification func(room *RoomInfo, notificationType RoomNotificationType, args ...interface{})
type RoomNotificationType int
const (
	_ RoomNotificationType = iota
	RoomNotificationTypeStartRound
	RoomNotificationTypeSyncClient
	RoomNotificationTypeShoot
	RoomNotificationTypePropShow
	RoomNotificationTypeBulletCollide
	RoomNotificationTypePropGot
	RoomNotificationTypePropInvalid
	RoomNotificationTypeEndRound
)

type RoomNotificationTypeStateChangedPayload struct {
	oldState RoomState
	newState RoomState
}

type RoomInfo struct {
	roomId string
	members []*Member
	state RoomState
	currentRound int32
	stateTime int64
	shootTime int64
	shoot bool
	notification RoomNotification
	updateTime int64
	syncTime int64
	shieldProp *Prop
	trackProp *Prop
}

type HitResult struct {
	member *Member
	bullet *Bullet
}

func NewRoom(roomId string, userId string, notification RoomNotification) *RoomInfo {
	return &RoomInfo{
		roomId: roomId,
		members: []*Member{NewMember(userId)},
		state: RoomStateCreating,
		currentRound: 0,
		stateTime: ReadyTimeInterval,
		shootTime: ShootTimeInterval,
		shoot: false,
		notification: notification,
		updateTime: time.Now().UnixNano(),
		syncTime: SyncTimeInterval,
		shieldProp: nil,
		trackProp: nil,
	}
}

func (room *RoomInfo) add(userId string) bool {
	if room.find(userId) != nil {
		return false
	}
	if room.isFull() {
		return false
	}
	room.members = append(room.members, NewMember(userId))
	return true
}

func (room *RoomInfo) isFull() bool  {
	return len(room.members) == 2
}

func (room *RoomInfo) find(userId string) *Member {
	for _, a := range room.members {
		if a.userId == userId {
			return a
		}
	}
	return nil
}

// 每隔duration这个时间刷新房间信息，单位为毫秒
func (room *RoomInfo) update() {
	now := time.Now().UnixNano()
	duration := now - room.updateTime
	room.updateTime = now
	if room.state == RoomStateWaiting || room.state == RoomStateResting {
		room.stateTime -= duration
		if room.stateTime <= 0 {
			room.setState(RoomStatePlaying, RoundTimeInterval)
			room.currentRound++
			room.notification(room, RoomNotificationTypeStartRound, nil)
			room.shieldProp = NewProp(room, PropTypeShield, -1)
			room.trackProp = NewProp(room, PropTypeTrack, room.shieldProp.area)
			for _, member := range room.members {
				member.init()
			}
		}
		return
	}
	if room.state == RoomStatePlaying {
		for _, member := range room.members {
			member.update(duration)
		}
		room.shieldProp.update(duration)
		room.trackProp.update(duration)
		room.shootTime -= duration
		room.syncTime -= duration
		if room.syncTime <= 0 {
			if room.shootTime <= 0 {
				room.shootTime = ShootTimeInterval
				room.notification(room, RoomNotificationTypeShoot, nil)
				for _, member := range room.members {
					member.shoot(room.getBulletCount())
				}
			}
			room.notification(room, RoomNotificationTypeSyncClient, nil)
			room.syncTime = SyncTimeInterval
		}

		// 碰撞检测
		collideBullets := []*Bullet{}
		hitResults := []*HitResult{}
		bulletCollide := false
		for _, member := range room.members {
			for _, bullet := range member.bullets {

				if room.shieldProp.shown {
					if bullet.collide(TargetTypeProp, room.shieldProp) {
						room.notification(room, RoomNotificationTypePropGot, bullet, room.shieldProp)
						member.gotProp(room.shieldProp)
						member.removeBullet(bullet)
						room.shieldProp = NewProp(room, PropTypeShield, room.trackProp.area)
						log.Debug("collide bullet %d prop %d", bullet.bulletId, room.shieldProp.propId)
						continue
					}
				}
				if room.trackProp.shown {
					if bullet.collide(TargetTypeProp, room.trackProp) {
						room.notification(room, RoomNotificationTypePropGot, bullet, room.trackProp)
						member.gotProp(room.trackProp)
						member.removeBullet(bullet)
						room.trackProp = NewProp(room, PropTypeTrack, room.shieldProp.area)
						log.Debug("collide bullet %d prop %d", bullet.bulletId, room.trackProp.propId)
						continue
					}
				}
				for _, member1 := range room.members {
					if bullet.player == member1 {
						continue
					}
					bulletDismiss := false
					for _, bullet1 := range member1.bullets {
						if bullet.collide(TargetTypeBullet, bullet1) {
							collideBullets = append(collideBullets, bullet, bullet1)
							member.removeBullet(bullet)
							member1.removeBullet(bullet1)
							bulletDismiss = true
							bulletCollide = true
							log.Debug("collide bullet %f bullet %f", bullet.x, bullet1.x)
							break
						}
					}
					if bulletDismiss {
						break
					}
					if bullet.collide(TargetTypeMember, member1) {
						member.removeBullet(bullet)
						hitResults = append(hitResults, &HitResult{
							member: member1,
							bullet: bullet,
						})
						log.Debug("collide bullet %d member %s", bullet.bulletId, member1.userId)
						break
					}
				}
			}
		}
		if bulletCollide {
			room.notification(room, RoomNotificationTypeBulletCollide, collideBullets)
		}
		roundEnd := false
		gameOver := false
		for _, result := range hitResults {
			if result.member.hasShield {
				result.member.loseShield()
				room.notification(room, RoomNotificationTypePropInvalid, result.bullet, result.member)
			} else {
				roundEnd = true
				if result.member.alive {
					result.member.alive = false
					result.member.life--
				}
				if result.member.life <= 0 {
					gameOver = true
				}
			}
		}
		if roundEnd {
			room.endRound(gameOver)
		}
		return
	}
}

func (room *RoomInfo) endRound (gameOver bool) {

	roomState := RoomStateResting
	if gameOver {
		roomState = RoomStateOver
	}
	room.setState(roomState, RestTimeInterval)
	room.notification(room, RoomNotificationTypeEndRound, gameOver)
}

func (room *RoomInfo) setState(state RoomState, time int64) {
	room.state = state
	room.stateTime = time
}

func (room *RoomInfo) getBulletCount() int {
	switch room.currentRound {
	case 3, 4:
		return 2
	case 5:
		return 3
	default:
		return 1
	}
}

func (room *RoomInfo) showProp(propType PropType) {
	room.notification(room, RoomNotificationTypePropShow, propType)
}