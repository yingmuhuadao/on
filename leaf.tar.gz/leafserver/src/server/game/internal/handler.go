package internal

import (
	"github.com/name5566/leaf/log"
	"reflect"
	"server/msg"
	"github.com/name5566/leaf/gate"
	"github.com/golang/protobuf/proto"
	"sync"
	"time"
	"net/http"
	"server/conf"
)

var clients sync.Map
var rooms sync.Map

// 刷新所有房间状态的时间间隔，单位毫秒
const UpdateInterval = 30

type httpHandler struct{}

func (h *httpHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	//w.Write([]byte(r.Method + r.URL.Path))
	if r.Method == "POST" && r.URL.Path == "/createRoom" {
		response := &Response{
			ErrorCode: 0,
			ErrorMsg: "ok",
		}
		w.Write([]byte(response.toJsonString()))
	}
}

func startHttp() {
	http.Handle("/", &httpHandler{})
	http.ListenAndServe(conf.Server.HttpAddr, nil)
}

func init() {
	// 向当前模块（game 模块）注册消息的消息处理函数
	handler(&msg.Request{}, handleRequest)
	handler(&msg.Ack{}, handleAck)
	// 开启http服务
	go startHttp()
	// 开启定时器
	startTimer()
}

func startTimer() {
	skeleton.AfterFunc(UpdateInterval * time.Millisecond, func() {
		go onTimer()
		startTimer()
	})
}

func onTimer() {
	rooms.Range(func(key, value interface{}) bool {
		room := value.(*RoomInfo)
		room.update()
		return true
	})
}

func handler(m interface{}, h interface{}) {
	skeleton.RegisterChanRPC(reflect.TypeOf(m), h)
}

func handleRequest(args []interface{}) {
	// 收到的 Request 消息
	request := args[0].(*msg.Request)
	// 消息的发送者
	agent := args[1].(gate.Agent)

	switch request.GetCommand() {
	case "game.start":
		handleStart(request, agent)
		break
	case "player.fly":
		handleFly(request, agent)
		break
	}
}

func handleAck(args []interface{}) {
	// 收到的 Ack 消息
	//m := args[0].(*msg.Ack)
	//log.Debug("ack");
}

func handleStart(request *msg.Request, agent gate.Agent) {
	userId := request.GetUserId()
	clients.Store(userId, agent)
	stReceive := &msg.GameStartRequest{}
	err := proto.Unmarshal(request.GetPayload(), stReceive)
	if err != nil {
		return
	}
	roomId := stReceive.GetRoomId()
	roomInfo := joinRoom(roomId, userId)
	if roomInfo != nil && roomInfo.isFull() {
		roomInfo.setState(RoomStateWaiting, ReadyTimeInterval)
		stPush := &msg.GameStartPush{
			RoomId: roomId,
		}
		pushData, err := proto.Marshal(stPush)
		if err != nil {
			return
		}
		sendRoomPush(roomInfo, "push.game.start", pushData, "")
	}
}

func handleFly(request *msg.Request, agent gate.Agent) {
	userId := request.GetUserId()
	stReceive := &msg.PlayerFlyRequest{}
	err := proto.Unmarshal(request.GetPayload(), stReceive)
	if err != nil {
		return
	}
	roomId := stReceive.GetRoomId()
	room, result := rooms.Load(roomId)
	if !result {
		return
	}
	room.(*RoomInfo).update()
	player := room.(*RoomInfo).find(userId)
	if player == nil {
		return
	}
	player.fly()
	stPush := &msg.PlayerFlyPush{
		RoomId: roomId,
		UserId: userId,
	}
	pushData, err := proto.Marshal(stPush)
	if err != nil {
		return
	}
	sendRoomPush(room.(*RoomInfo), "push.player.fly", pushData, userId)
}

func joinRoom(roomId string, userId string) *RoomInfo {
	log.Debug("user %s wants to join room %s", userId, roomId)
	roomInfo, result := rooms.Load(roomId)
	if !result {
		roomInfo = NewRoom(roomId, userId, onRoomNotification)
		log.Debug("roominfo %v", roomInfo)
		rooms.Store(roomId, roomInfo)
		return roomInfo.(*RoomInfo)
	}
	if roomInfo.(*RoomInfo).add(userId) {
		rooms.Store(roomId, roomInfo)
		return roomInfo.(*RoomInfo)
	}
	return nil
}

func startRound(room *RoomInfo) {
	stPush := &msg.RoundStartPush{
		RoomId: room.roomId,
		Round: room.currentRound,
	}
	pushData, err := proto.Marshal(stPush)
	if err != nil {
		return
	}
	sendRoomPush(room, "push.round.start", pushData, "")
}

func syncClient(room *RoomInfo) {
	var players []*msg.Player
	for _, member := range room.members {
		var bullets []*msg.Bullet
		for _, bullet := range member.bullets {
			log.Debug("bullet %d bullet position %f",  bullet.bulletId, bullet.y)
			bullets = append(bullets, &msg.Bullet{
				BulletId: bullet.bulletId,
				X: int32(bullet.x),
				Y: int32(bullet.y),
				Vx: int32(bullet.vx),
				Vy: int32(bullet.vy),
			})
		}
		player := &msg.Player{
			UserId: member.userId,
			Life: member.life,
			Position: int32(member.position),
			Speed: int32(member.speed),
			Alive: member.alive,
			Bullets: bullets,
			HasShield: member.hasShield,
			HasTrack: member.hasTrack,
		}
		players = append(players, player)
	}
	stPush := &msg.GameSyncPush{
		RoomId: room.roomId,
		Players: players,
	}
	pushData, err := proto.Marshal(stPush)
	if err != nil {
		return
	}
	sendRoomPush(room, "push.game.sync", pushData, "")
}

func shoot(room *RoomInfo)  {
	stPush := &msg.PlayerShootPush{
		RoomId: room.roomId,
	}
	pushData, err := proto.Marshal(stPush)
	if err != nil {
		return
	}
	sendRoomPush(room, "push.player.shoot", pushData, "")
}

func showProp(room *RoomInfo, pt PropType) {
	propType := msg.PropType_SHIELD
	prop := room.shieldProp
	if pt == PropTypeTrack {
		propType = msg.PropType_TRACK
		prop = room.trackProp
	}
	stPush := &msg.PropShowPush{
		RoomId: room.roomId,
		Type: propType,
		PropId: prop.propId,
		Position: int32(prop.position),
	}
	pushData, err := proto.Marshal(stPush)
	if err != nil {
		return
	}
	sendRoomPush(room, "push.prop.show", pushData, "")
}

func bulletCollide(room *RoomInfo, bullets []*Bullet) {
	bulletIds := []string{}
	x := float64(0)
	y := float64(0)
	for _, bullet := range bullets {
		bulletIds = append(bulletIds, bullet.bulletId)
		x += bullet.x
		y += bullet.y
	}

	stPush := &msg.BulletCollidePush{
		RoomId: room.roomId,
		Bullets: bulletIds,
		X: int32(x / float64(len(bullets))),
		Y: int32(y / float64(len(bullets))),
	}
	pushData, err := proto.Marshal(stPush)
	if err != nil {
		return
	}
	sendRoomPush(room, "push.bullet.collide", pushData, "")
}

func propGot(room *RoomInfo, bullet *Bullet, prop *Prop) {
	propType := msg.PropType_SHIELD
	if prop.propType == PropTypeTrack {
		propType = msg.PropType_TRACK
	}
	stPush := &msg.PropGotPush{
		RoomId: room.roomId,
		UserId: bullet.player.userId,
		Type: propType,
		PropId: prop.propId,
		BulletId: bullet.bulletId,
	}
	pushData, err := proto.Marshal(stPush)
	if err != nil {
		return
	}
	sendRoomPush(room, "push.prop.got", pushData, "")
}

func propInvalid(room *RoomInfo, bullet *Bullet, member *Member) {
	stPush := &msg.PropInvalidPush{
		RoomId: room.roomId,
		UserId: member.userId,
		Type: msg.PropType_SHIELD,
		BulletId: bullet.bulletId,
	}
	pushData, err := proto.Marshal(stPush)
	if err != nil {
		return
	}
	sendRoomPush(room, "push.prop.invalid", pushData, "")
}

func roundEnd(room *RoomInfo, gameOver bool) {

	//TODO: 清除room
	var players []*msg.Player
	for _, member := range room.members {
		player := &msg.Player{
			UserId: member.userId,
			Life: member.life,
			Alive: member.alive,
		}
		players = append(players, player)
	}
	stPush := &msg.RoundEndPush{
		RoomId: room.roomId,
		Players: players,
		GameOver: gameOver,
	}
	pushData, err := proto.Marshal(stPush)
	if err != nil {
		return
	}
	sendRoomPush(room, "push.round.end", pushData, "")
}

func sendRoomPush(room *RoomInfo, command string, data []byte, except string) {
	for _, member := range room.members {
		if member.userId != except {
			sendPush(member.userId, command, data)
		}
	}
}

func sendPush(userId string, command string, data []byte) {
	client, result := clients.Load(userId)
	if !result {
		return
	}
	//log.Debug("send push to %s", userId)
	client.(gate.Agent).WriteMsg(&msg.Push{
		Command: command,
		SeqId: time.Now().UnixNano(),
		Payload: data,
	})
}

func onRoomNotification(room *RoomInfo, notificationType RoomNotificationType, args ...interface{}) {
	switch notificationType {
	case RoomNotificationTypeStartRound:
		startRound(room)
		break
	case RoomNotificationTypeSyncClient:
		syncClient(room)
		break
	case RoomNotificationTypeShoot:
		shoot(room)
		break
	case RoomNotificationTypePropShow:
		showProp(room, args[0].(PropType))
		break
	case RoomNotificationTypeBulletCollide:
		bulletCollide(room, args[0].([]*Bullet));
		break
	case RoomNotificationTypePropGot:
		propGot(room, args[0].(*Bullet), args[1].(*Prop))
		break
	case RoomNotificationTypePropInvalid:
		propInvalid(room, args[0].(*Bullet), args[1].(*Member))
		break
	case RoomNotificationTypeEndRound:
		roundEnd(room, args[0].(bool))
		break
	}
}
