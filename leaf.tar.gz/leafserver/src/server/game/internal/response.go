package internal

import (
	"encoding/json"
	"fmt"
)

type Response struct {
	ErrorCode  int32   `json:"errorCode"`
	ErrorMsg   string  `json:"errorMsg"`
}

func (response *Response) toJsonString () string {
	b, err := json.Marshal(response)
	if err != nil {
		fmt.Println("json err:", err)
		return ""
	}
	return string(b)
}